# Bastugubben - Råd & Visdom

En AI-chattbot som ger råd och rekommendationer som en äldre bastugubbe på det lokala badhuset.

## 🛁 Om projektet

Bastugubben är en variant av Avreagera Dig där användare får råd och visdom från en AI som pratar som en äldre gubbe i bastun. Personligheten är baserad på en 75-80 år gammal man som har sett allt i livet och ger praktiska, raka råd baserat på livserfarenhet.

## 🎭 Personlighet

Bastugubben pratar:
- Långsamt och eftertänksamt
- Använder uttryck som "grabben", "gumman", "kära du"
- Säger saker som "Ja du, jag har fan sett mycket i mitt liv"
- Ger praktiska råd och använder gamla talesätt
- Är rakt på sak - tycker folk ska ta ansvar och göra något
- Slutar ofta med "Lycka till grabben" eller "Håll huvudet högt gumman"

## 🚀 Deployment

Projektet är deployat på Vercel.

### Miljövariabler:
- `OPENAI_API_KEY` - Din OpenAI API-nyckel

## 📝 Teknisk info

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Vercel Serverless Functions
- **AI**: OpenAI GPT-3.5-turbo
- **Hosting**: Vercel

## 🔧 Lokal utveckling

```bash
npm install
npm run dev
```

## 📄 Licens

MIT
