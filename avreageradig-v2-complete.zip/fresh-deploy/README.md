# 💝 Avreagera Dig - Sofia's Stödplattform

En säker plats att ventilera känslor med AI-stöd från Sofia.

## 🚀 Snabb Deployment

### Vercel (Rekommenderat)
1. Gå till https://vercel.com/new
2. Logga in med GitHub
3. Välj denna repository
4. Konfigurera Environment Variable:
   - Name: `OPENAI_API_KEY`
   - Value: Din OpenAI API-nyckel
5. Klicka "Deploy"

### Netlify
1. Gå till https://netlify.com
2. Logga in med GitHub
3. Välj denna repository
4. Konfigurera Environment Variable:
   - Name: `OPENAI_API_KEY`
   - Value: Din OpenAI API-nyckel
5. Klicka "Deploy site"

### GitHub Pages
1. Gå till Settings → Pages
2. Source: Deploy from a branch
3. Branch: main
4. Klicka "Save"

## 🧪 Lokal utveckling

```bash
python3 -m http.server 8000
```

Öppna http://localhost:8000

## 🔒 Säkerhet

- API-nyckel lagras säkert i miljövariabler
- Ingen känslig data i koden
- Lokal lagring för anonymitet

## 📱 Funktioner

- 🤖 Sofia's AI-stöd med tough love
- ⌨️ Enter-tangent för snabb skickning
- 📋 Gemenskapsanslagstavla
- 👮 Admin-moderering
- 📱 Responsiv design




