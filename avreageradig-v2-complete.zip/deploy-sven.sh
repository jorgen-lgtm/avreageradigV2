#!/bin/bash

# 🧖‍♂️ Sven AI Deployment Script
# Detta skript hjälper dig att deploya Sven med riktig AI

echo "🧖‍♂️ Bastugubben Sven - AI Deployment"
echo "====================================="
echo ""

# Färger för output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# API-nyckel
API_KEY="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"

echo -e "${GREEN}✅ Sven's filer kontrollerade:${NC}"
echo "  - bastugubben-sven.html (GUI)"
echo "  - api/sven.js (AI function)"
echo "  - vercel.json (routing)"
echo ""

echo -e "${BLUE}🚀 Deployment Alternativ:${NC}"
echo ""
echo "1. 🌟 Vercel (Rekommenderat för riktig AI)"
echo "2. 🌐 Netlify (Alternativ)"
echo "3. 📄 GitHub Pages (Enkel, men ingen AI)"
echo "4. 🧪 Lokal test (Simulerade svar)"
echo ""

# Vercel deployment
deploy_vercel() {
    echo -e "${BLUE}🌟 Vercel Deployment för Sven${NC}"
    echo "================================"
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://vercel.com/new"
    echo "2. Logga in med GitHub"
    echo "3. Välj repository: jorgen-lgtm/avreageradig"
    echo "4. Klicka 'Import'"
    echo "5. Konfigurera Environment Variable:"
    echo "   - Name: OPENAI_API_KEY"
    echo "   - Value: $API_KEY"
    echo "   - Environment: Production, Preview, Development"
    echo "6. Klicka 'Deploy'"
    echo ""
    echo -e "${GREEN}Resultat:${NC}"
    echo "  - Sven: https://avreageradig.vercel.app/sven"
    echo "  - Huvudsida: https://avreageradig.vercel.app"
    echo "  - Demo: https://avreageradig.vercel.app/demo"
    echo ""
    echo -e "${YELLOW}🎯 Sven kommer att använda riktig AI!${NC}"
    echo ""
    
    # Öppna Vercel
    if command -v open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        open "https://vercel.com/new"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        xdg-open "https://vercel.com/new"
    else
        echo "Öppna manuellt: https://vercel.com/new"
    fi
}

# Netlify deployment
deploy_netlify() {
    echo -e "${BLUE}🌐 Netlify Deployment för Sven${NC}"
    echo "=================================="
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://netlify.com"
    echo "2. Logga in med GitHub"
    echo "3. Klicka 'New site from Git'"
    echo "4. Välj din repository"
    echo "5. Konfigurera Environment Variable:"
    echo "   - Name: OPENAI_API_KEY"
    echo "   - Value: $API_KEY"
    echo "6. Klicka 'Deploy site'"
    echo ""
    echo -e "${GREEN}Resultat: https://avreageradig.netlify.app/sven${NC}"
    echo ""
    
    # Öppna Netlify
    if command -v open &> /dev/null; then
        echo "Öppnar Netlify Dashboard..."
        open "https://netlify.com"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Netlify Dashboard..."
        xdg-open "https://netlify.com"
    else
        echo "Öppna manuellt: https://netlify.com"
    fi
}

# GitHub Pages deployment
deploy_github() {
    echo -e "${BLUE}📄 GitHub Pages Deployment${NC}"
    echo "============================="
    echo ""
    echo "Steg-för-steg:"
    echo "1. Push kod till GitHub:"
    echo "   git add ."
    echo "   git commit -m 'Add Sven AI'"
    echo "   git push origin main"
    echo "2. Gå till: https://github.com/jorgen-lgtm/avreageradig"
    echo "3. Settings → Pages"
    echo "4. Source: Deploy from a branch → main"
    echo "5. Klicka 'Save'"
    echo ""
    echo -e "${GREEN}Resultat: https://jorgen-lgtm.github.io/avreageradig/sven${NC}"
    echo -e "${YELLOW}OBS: GitHub Pages använder simulerade svar (ingen AI)${NC}"
    echo ""
    
    # Öppna GitHub
    if command -v open &> /dev/null; then
        echo "Öppnar GitHub Repository..."
        open "https://github.com/jorgen-lgtm/avreageradig"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar GitHub Repository..."
        xdg-open "https://github.com/jorgen-lgtm/avreageradig"
    else
        echo "Öppna manuellt: https://github.com/jorgen-lgtm/avreageradig"
    fi
}

# Lokal test
test_local() {
    echo -e "${BLUE}🧪 Lokal Test av Sven${NC}"
    echo "======================="
    echo ""
    echo "Sven körs redan lokalt på port 9000"
    echo "Öppna: http://localhost:9000/bastugubben-sven.html"
    echo ""
    echo -e "${YELLOW}OBS: Lokal version använder simulerade svar${NC}"
    echo "För riktig AI, deploya till Vercel eller Netlify"
    echo ""
    
    # Öppna lokal version
    if command -v open &> /dev/null; then
        echo "Öppnar Sven lokalt..."
        open "http://localhost:9000/bastugubben-sven.html"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Sven lokalt..."
        xdg-open "http://localhost:9000/bastugubben-sven.html"
    else
        echo "Öppna manuellt: http://localhost:9000/bastugubben-sven.html"
    fi
}

# Visa API-nyckel
show_api_key() {
    echo -e "${BLUE}🔑 OpenAI API-nyckel${NC}"
    echo "=================="
    echo ""
    echo "API-nyckel för deployment:"
    echo -e "${YELLOW}$API_KEY${NC}"
    echo ""
    echo "Denna nyckel ska läggas till som Environment Variable:"
    echo "Name: OPENAI_API_KEY"
    echo "Value: [nyckeln ovan]"
    echo ""
}

# Huvudloop
main() {
    while true; do
        echo -e "${CYAN}Välj deployment-alternativ:${NC}"
        echo ""
        echo "1. 🌟 Vercel (Rekommenderat för riktig AI)"
        echo "2. 🌐 Netlify (Alternativ)"
        echo "3. 📄 GitHub Pages (Enkel, men ingen AI)"
        echo "4. 🧪 Lokal test (Simulerade svar)"
        echo "5. 🔧 Visa API-nyckel"
        echo "6. ❌ Avsluta"
        echo ""
        read -p "Välj alternativ (1-6): " choice
        
        case $choice in
            1)
                deploy_vercel
                ;;
            2)
                deploy_netlify
                ;;
            3)
                deploy_github
                ;;
            4)
                test_local
                ;;
            5)
                show_api_key
                ;;
            6)
                echo -e "${GREEN}👋 Tack för att du använde Sven deployment-scriptet!${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}❌ Ogiltigt val. Välj 1-6.${NC}"
                ;;
        esac
        
        echo ""
        read -p "Tryck Enter för att fortsätta..."
        echo ""
    done
}

# Kör huvudfunktionen
main
