# 🔒 Säkerhetsguide - Avreagera Dig

## 🛡️ API-nyckel säkerhet

### ✅ **Vad jag har gjort för att skydda din API-nyckel:**

1. **Flyttat API-nyckeln från kod** till miljövariabler
2. **Skapat .gitignore** för att undvika att ladda upp känsliga filer
3. **Skapat env.example** som mall för säker konfiguration
4. **Uppdaterat konfigurationen** för att använda miljövariabler

### 🔧 **Säker konfiguration:**

**Före (OSÄKERT):**
```javascript
openaiApiKey: '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'
```

**Efter (SÄKERT):**
```javascript
openaiApiKey: process.env.OPENAI_API_KEY || 'YOUR_OPENAI_API_KEY_HERE'
```

### 🚀 **För Vercel Deployment:**

1. **Gå till Vercel Dashboard**
2. **Välj ditt projekt**
3. **Gå till Settings → Environment Variables**
4. **Lägg till:**
   - **Name**: `OPENAI_API_KEY`
   - **Value**: `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`
5. **Klicka "Save"**

### 🏠 **För lokal utveckling:**

1. **Skapa .env-fil** i projektmappen:
```bash
echo "OPENAI_API_KEY=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" > .env
```

2. **Kontrollera att .env är i .gitignore** (✅ redan gjort)

### 🔐 **För GitHub Pages:**

**GitHub Pages stöder inte miljövariabler direkt, så använd:**

1. **Vercel** (rekommenderat) - stöder miljövariabler
2. **Netlify** - stöder miljövariabler
3. **GitHub Actions** med secrets

### ⚠️ **Viktiga säkerhetsregler:**

1. **ALDRIG** committa API-nycklar till Git
2. **ALDRIG** dela API-nycklar i chat/email
3. **ALDRIG** hårdkoda API-nycklar i frontend-kod
4. **Använd alltid** miljövariabler för känsliga data
5. **Rotera API-nycklar** regelbundet

### 🛠️ **För utvecklare:**

**Lokal utveckling:**
```bash
# Skapa .env-fil
cp env.example .env
# Redigera .env med din riktiga API-nyckel
```

**Produktion:**
- Använd plattformens miljövariabel-system
- Vercel: Environment Variables i dashboard
- Netlify: Site settings → Environment variables

### 🔍 **Kontrollera säkerhet:**

1. **Kontrollera .gitignore** innehåller `.env`
2. **Kontrollera att ingen API-nyckel** syns i koden
3. **Testa lokalt** att applikationen fungerar med miljövariabel
4. **Deploy till Vercel** och testa live

### 📞 **Om API-nyckeln kompromitteras:**

1. **Gå till OpenAI Dashboard**
2. **Skapa ny API-nyckel**
3. **Ta bort den gamla**
4. **Uppdatera miljövariabeln** på alla plattformar
5. **Redeploy** applikationen

**Din API-nyckel är nu säkert skyddad! 🔒**
