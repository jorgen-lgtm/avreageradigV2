#!/bin/bash

# 🚀 Avreagera Dig V2 - Vercel Deployment Script
# Deployar appen till https://avreageradig-v2-bgzu.vercel.app/

echo "🚀 Avreagera Dig V2 - Vercel Deployment"
echo "======================================"
echo ""

# Färger för output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# API-nyckel
API_KEY="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"

echo -e "${GREEN}✅ Projekt information:${NC}"
echo "  - Projekt: Avreagera Dig V2"
echo "  - Vercel URL: https://avreageradig-v2-bgzu.vercel.app/"
echo "  - Repository: jorgen-lgtm/avreageradig"
echo ""

echo -e "${BLUE}🎯 Deployment Alternativ:${NC}"
echo ""
echo "1. 🌟 Vercel Dashboard (Rekommenderat)"
echo "2. 🔧 Vercel CLI (Om installerat)"
echo "3. 📄 GitHub Push (Automatisk deployment)"
echo "4. 🧪 Lokal test"
echo "5. 🔑 Visa API-nyckel"
echo "6. ❌ Avsluta"
echo ""

# Vercel Dashboard deployment
deploy_vercel_dashboard() {
    echo -e "${BLUE}🌟 Vercel Dashboard Deployment${NC}"
    echo "================================"
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://vercel.com/dashboard"
    echo "2. Hitta ditt projekt: avreageradig-v2"
    echo "3. Klicka på projektet"
    echo "4. Gå till Settings → Environment Variables"
    echo "5. Lägg till ny variabel:"
    echo "   - Name: OPENAI_API_KEY"
    echo "   - Value: $API_KEY"
    echo "   - Environment: Production, Preview, Development"
    echo "6. Klicka 'Save'"
    echo "7. Gå till Deployments och klicka 'Redeploy'"
    echo ""
    echo -e "${GREEN}Resultat:${NC}"
    echo "  - Huvudsida: https://avreageradig-v2-bgzu.vercel.app/"
    echo "  - Sven: https://avreageradig-v2-bgzu.vercel.app/sven"
    echo "  - Demo: https://avreageradig-v2-bgzu.vercel.app/demo"
    echo ""
    echo -e "${YELLOW}🎯 Sven kommer att använda riktig AI!${NC}"
    echo ""
    
    # Öppna Vercel Dashboard
    if command -v open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        open "https://vercel.com/dashboard"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        xdg-open "https://vercel.com/dashboard"
    else
        echo "Öppna manuellt: https://vercel.com/dashboard"
    fi
}

# Vercel CLI deployment
deploy_vercel_cli() {
    echo -e "${BLUE}🔧 Vercel CLI Deployment${NC}"
    echo "========================"
    echo ""
    echo "Kontrollerar Vercel CLI..."
    
    if command -v vercel &> /dev/null; then
        echo -e "${GREEN}✅ Vercel CLI hittad!${NC}"
        echo ""
        echo "Deployar till Vercel..."
        echo "1. Logga in: vercel login"
        echo "2. Deploy: vercel --prod"
        echo "3. Lägg till environment variable:"
        echo "   vercel env add OPENAI_API_KEY"
        echo "   (Ange värdet: $API_KEY)"
        echo ""
        echo "Vill du köra deployment nu? (y/n)"
        read -p "> " choice
        if [[ $choice == "y" || $choice == "Y" ]]; then
            echo "Kör vercel login..."
            vercel login
            echo "Deployar..."
            vercel --prod
        fi
    else
        echo -e "${RED}❌ Vercel CLI inte installerat${NC}"
        echo ""
        echo "Installera Vercel CLI:"
        echo "npm install -g vercel"
        echo ""
        echo "Eller använd Vercel Dashboard istället (alternativ 1)"
    fi
}

# GitHub Push deployment
deploy_github_push() {
    echo -e "${BLUE}📄 GitHub Push Deployment${NC}"
    echo "=========================="
    echo ""
    echo "Pushar kod till GitHub för automatisk deployment..."
    echo ""
    echo "Steg:"
    echo "1. git add ."
    echo "2. git commit -m 'Update Sven AI'"
    echo "3. git push origin main"
    echo ""
    echo "Vercel kommer automatiskt att deploya när du pushar!"
    echo ""
    echo "Vill du köra git push nu? (y/n)"
    read -p "> " choice
    if [[ $choice == "y" || $choice == "Y" ]]; then
        echo "Lägger till filer..."
        git add .
        echo "Commitar ändringar..."
        git commit -m "Update Sven AI and deployment"
        echo "Pushar till GitHub..."
        git push origin main
        echo ""
        echo -e "${GREEN}✅ Kod pushad! Vercel deployar automatiskt...${NC}"
        echo "Kontrollera: https://vercel.com/dashboard"
    fi
}

# Lokal test
test_local() {
    echo -e "${BLUE}🧪 Lokal Test${NC}"
    echo "=============="
    echo ""
    echo "Sven körs redan lokalt på port 9000"
    echo "Öppna: http://localhost:9000/bastugubben-sven.html"
    echo ""
    echo -e "${YELLOW}OBS: Lokal version använder simulerade svar${NC}"
    echo "För riktig AI, deploya till Vercel"
    echo ""
    
    # Öppna lokal version
    if command -v open &> /dev/null; then
        echo "Öppnar Sven lokalt..."
        open "http://localhost:9000/bastugubben-sven.html"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Sven lokalt..."
        xdg-open "http://localhost:9000/bastugubben-sven.html"
    else
        echo "Öppna manuellt: http://localhost:9000/bastugubben-sven.html"
    fi
}

# Visa API-nyckel
show_api_key() {
    echo -e "${BLUE}🔑 OpenAI API-nyckel${NC}"
    echo "=================="
    echo ""
    echo "API-nyckel för Vercel Environment Variables:"
    echo -e "${YELLOW}$API_KEY${NC}"
    echo ""
    echo "Lägg till denna som Environment Variable i Vercel:"
    echo "Name: OPENAI_API_KEY"
    echo "Value: [nyckeln ovan]"
    echo ""
    echo "Vercel Dashboard: https://vercel.com/dashboard"
    echo "Projekt: avreageradig-v2"
    echo "Settings → Environment Variables"
}

# Huvudloop
main() {
    while true; do
        echo -e "${CYAN}Välj deployment-alternativ:${NC}"
        echo ""
        echo "1. 🌟 Vercel Dashboard (Rekommenderat)"
        echo "2. 🔧 Vercel CLI"
        echo "3. 📄 GitHub Push (Automatisk deployment)"
        echo "4. 🧪 Lokal test"
        echo "5. 🔑 Visa API-nyckel"
        echo "6. ❌ Avsluta"
        echo ""
        read -p "Välj alternativ (1-6): " choice
        
        case $choice in
            1)
                deploy_vercel_dashboard
                ;;
            2)
                deploy_vercel_cli
                ;;
            3)
                deploy_github_push
                ;;
            4)
                test_local
                ;;
            5)
                show_api_key
                ;;
            6)
                echo -e "${GREEN}👋 Tack för att du använde deployment-scriptet!${NC}"
                echo ""
                echo -e "${BLUE}🎯 Nästa steg:${NC}"
                echo "1. Deploya till Vercel"
                echo "2. Lägg till API-nyckel som Environment Variable"
                echo "3. Testa Sven med riktig AI på: https://avreageradig-v2-bgzu.vercel.app/sven"
                echo ""
                exit 0
                ;;
            *)
                echo -e "${RED}❌ Ogiltigt val. Välj 1-6.${NC}"
                ;;
        esac
        
        echo ""
        read -p "Tryck Enter för att fortsätta..."
        echo ""
    done
}

# Kör huvudfunktionen
main
