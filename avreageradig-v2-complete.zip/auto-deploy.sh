#!/bin/bash

# 🚀 Avreagera Dig - Automatisk Deployment Script
# Detta skript hjälper dig att deploya Sofia's stödplattform på olika plattformar

echo "💝 Avreagera Dig - Automatisk Deployment"
echo "========================================"
echo ""

# Färger för output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# API-nyckel
API_KEY="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"

# Kontrollera att zip-filen finns
if [ ! -f "avreagera-dig-LATEST-API.zip" ]; then
    echo -e "${RED}❌ Fel: avreagera-dig-LATEST-API.zip hittades inte!${NC}"
    echo "Kontrollera att du är i rätt mapp och att zip-filen finns."
    exit 1
fi

echo -e "${GREEN}✅ Zip-fil hittad: avreagera-dig-LATEST-API.zip${NC}"
echo ""

# Visa meny
show_menu() {
    echo -e "${CYAN}Välj deployment-alternativ:${NC}"
    echo ""
    echo "1. 🌟 Vercel (Rekommenderat)"
    echo "2. 🌐 Netlify"
    echo "3. 📄 GitHub Pages"
    echo "4. 🧪 Lokal test"
    echo "5. 📦 Extrahera zip-fil"
    echo "6. 🔧 Visa API-nyckel"
    echo "7. ❌ Avsluta"
    echo ""
}

# Vercel deployment
deploy_vercel() {
    echo -e "${BLUE}🚀 Vercel Deployment${NC}"
    echo "=========================="
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://vercel.com/new"
    echo "2. Logga in med GitHub"
    echo "3. Välj repository eller ladda upp zip-fil"
    echo "4. Konfigurera Environment Variable:"
    echo "   - Name: OPENAI_API_KEY"
    echo "   - Value: $API_KEY"
    echo "5. Klicka 'Deploy'"
    echo ""
    echo -e "${GREEN}Resultat: https://avreageradig.vercel.app${NC}"
    echo ""
    
    # Öppna Vercel i webbläsare
    if command -v open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        open "https://vercel.com/new"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Vercel Dashboard..."
        xdg-open "https://vercel.com/new"
    else
        echo "Öppna manuellt: https://vercel.com/new"
    fi
}

# Netlify deployment
deploy_netlify() {
    echo -e "${BLUE}🌐 Netlify Deployment${NC}"
    echo "========================"
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://netlify.com"
    echo "2. Logga in med GitHub"
    echo "3. Klicka 'New site from Git'"
    echo "4. Välj din repository"
    echo "5. Konfigurera Environment Variable:"
    echo "   - Name: OPENAI_API_KEY"
    echo "   - Value: $API_KEY"
    echo "6. Klicka 'Deploy site'"
    echo ""
    echo -e "${GREEN}Resultat: https://avreageradig.netlify.app${NC}"
    echo ""
    
    # Öppna Netlify i webbläsare
    if command -v open &> /dev/null; then
        echo "Öppnar Netlify Dashboard..."
        open "https://netlify.com"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar Netlify Dashboard..."
        xdg-open "https://netlify.com"
    else
        echo "Öppna manuellt: https://netlify.com"
    fi
}

# GitHub Pages deployment
deploy_github() {
    echo -e "${BLUE}📄 GitHub Pages Deployment${NC}"
    echo "============================="
    echo ""
    echo "Steg-för-steg:"
    echo "1. Gå till: https://github.com/jorgen-lgtm/avreageradig"
    echo "2. Ladda upp filer via GitHub web interface"
    echo "3. Gå till Settings → Pages"
    echo "4. Source: Deploy from a branch"
    echo "5. Branch: main"
    echo "6. Klicka 'Save'"
    echo ""
    echo -e "${GREEN}Resultat: https://jorgen-lgtm.github.io/avreageradig/${NC}"
    echo "OBS: GitHub Pages använder simulerade svar (ingen API-nyckel)"
    echo ""
    
    # Öppna GitHub i webbläsare
    if command -v open &> /dev/null; then
        echo "Öppnar GitHub Repository..."
        open "https://github.com/jorgen-lgtm/avreageradig"
    elif command -v xdg-open &> /dev/null; then
        echo "Öppnar GitHub Repository..."
        xdg-open "https://github.com/jorgen-lgtm/avreageradig"
    else
        echo "Öppna manuellt: https://github.com/jorgen-lgtm/avreageradig"
    fi
}

# Lokal test
test_local() {
    echo -e "${BLUE}🧪 Lokal Test${NC}"
    echo "=============="
    echo ""
    echo "Startar lokal server..."
    
    # Kontrollera om Python finns
    if command -v python3 &> /dev/null; then
        echo "Startar Python HTTP server på port 8000..."
        echo "Öppna: http://localhost:8000"
        echo ""
        echo "Tryck Ctrl+C för att stoppa servern"
        echo ""
        python3 -m http.server 8000
    else
        echo -e "${RED}❌ Python3 hittades inte!${NC}"
        echo "Installera Python3 för att köra lokal server."
    fi
}

# Extrahera zip-fil
extract_zip() {
    echo -e "${BLUE}📦 Extrahera Zip-fil${NC}"
    echo "====================="
    echo ""
    
    # Skapa mapp för extraktion
    EXTRACT_DIR="avreagera-dig-extracted"
    
    if [ -d "$EXTRACT_DIR" ]; then
        echo "Tar bort befintlig mapp..."
        rm -rf "$EXTRACT_DIR"
    fi
    
    echo "Skapar mapp: $EXTRACT_DIR"
    mkdir -p "$EXTRACT_DIR"
    
    echo "Extraherar zip-fil..."
    unzip -q "avreagera-dig-LATEST-API.zip" -d "$EXTRACT_DIR"
    
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✅ Zip-fil extraherad till: $EXTRACT_DIR${NC}"
        echo ""
        echo "Innehåll:"
        ls -la "$EXTRACT_DIR"
        echo ""
        echo "För att köra lokalt:"
        echo "cd $EXTRACT_DIR && python3 -m http.server 8000"
    else
        echo -e "${RED}❌ Fel vid extraktion av zip-fil!${NC}"
    fi
}

# Visa API-nyckel
show_api_key() {
    echo -e "${BLUE}🔑 API-nyckel Information${NC}"
    echo "========================="
    echo ""
    echo "OpenAI API-nyckel:"
    echo -e "${YELLOW}$API_KEY${NC}"
    echo ""
    echo "Denna nyckel är redan konfigurerad i zip-filen."
    echo "För production, använd miljövariabler istället."
    echo ""
    echo "Miljövariabel för deployment:"
    echo "Name: OPENAI_API_KEY"
    echo "Value: $API_KEY"
}

# Huvudloop
main() {
    while true; do
        show_menu
        read -p "Välj alternativ (1-7): " choice
        
        case $choice in
            1)
                deploy_vercel
                ;;
            2)
                deploy_netlify
                ;;
            3)
                deploy_github
                ;;
            4)
                test_local
                ;;
            5)
                extract_zip
                ;;
            6)
                show_api_key
                ;;
            7)
                echo -e "${GREEN}👋 Tack för att du använde deployment-scriptet!${NC}"
                exit 0
                ;;
            *)
                echo -e "${RED}❌ Ogiltigt val. Välj 1-7.${NC}"
                ;;
        esac
        
        echo ""
        read -p "Tryck Enter för att fortsätta..."
        echo ""
    done
}

# Kör huvudfunktionen
main




