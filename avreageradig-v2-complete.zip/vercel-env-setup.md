# 🔧 Vercel Environment Variables Setup

## 🚀 Steg-för-steg guide för säker deployment

### 1. **Gå till Vercel Dashboard**
- Besök: https://vercel.com/dashboard
- Logga in med ditt GitHub-konto

### 2. **Skapa nytt projekt**
- Klicka "New Project"
- Välj din GitHub repository: `jorgen-lgtm/avreageradig`
- Klicka "Import"

### 3. **Konfigurera Environment Variables**
- I projektinställningar, gå till "Settings"
- Klicka på "Environment Variables" i sidomenyn
- Lägg till följande variabel:

**Name:** `OPENAI_API_KEY`
**Value:** `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`
**Environment:** Production, Preview, Development (markera alla)

### 4. **Deploy**
- Klicka "Deploy"
- Vercel bygger automatiskt projektet
- Få din live-URL: `https://avreageradig.vercel.app`

### 5. **Testa Sofia**
- Öppna din live-URL
- Skriv en känsla: "Jag känner mig ledsen"
- Klicka "Få stöd från Sofia"
- Sofia ska ge ett empatiskt svar med din API-nyckel

## 🔒 Säkerhet
- ✅ API-nyckeln är säkert lagrad i Vercel
- ✅ Ingen API-nyckel syns i koden
- ✅ Automatisk deployment från GitHub
- ✅ HTTPS säker anslutning

## 📱 URL-struktur efter deployment
- **Huvudapplikation**: `https://avreageradig.vercel.app/app`
- **Demosida**: `https://avreageradig.vercel.app/demo`
- **Startsida**: `https://avreageradig.vercel.app/`

## 🧪 Testa funktioner
1. **Sofia:s AI-stöd** - Skriv känslor och få empatiska svar
2. **Anslagstavla** - Se andras inlägg och reaktioner
3. **Emoji-reaktioner** - Reagera på inlägg
4. **Admin-moderering** - Ta bort stötande kommentarer
5. **Responsiv design** - Fungerar på alla enheter

**Din applikation är nu säkert live! 🚀**
