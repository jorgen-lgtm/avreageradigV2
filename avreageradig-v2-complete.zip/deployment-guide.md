# Deployment Guide - Avreagera Dig

## Snabbstart för WordPress

### 1. Testa lokalt först
Öppna `test.html` i din webbläsare för att verifiera att OpenAI API fungerar korrekt.

### 2. Förbered filer för WordPress
Skapa en zip-fil med följande filer:
- `index.html` (huvudapplikation)
- `styles.css` (styling)
- `script.js` (funktionalitet)
- `config.js` (konfiguration med din API-nyckel)

### 3. WordPress-uppladdning

#### Alternativ A: Som statisk sida
1. Logga in på WordPress
2. Gå till **Sidor > Lägg till ny**
3. Välj **HTML-läge** i redigeraren
4. Kopiera innehållet från `index.html`
5. Ladda upp CSS och JS-filer via **Medier**
6. Uppdatera filvägar i HTML-koden

#### Alternativ B: Som tema
1. Zippa alla filer
2. Gå till **Utseende > Teman > Lägg till nytt > Ladda upp tema**
3. Välj din zip-fil
4. Aktivera temat

### 4. Konfiguration
Din OpenAI API-nyckel är redan konfigurerad i `config.js`:
```javascript
useOpenAI: true,
openaiApiKey: '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'
```

### 5. Testa live
1. Besök din WordPress-sida
2. Testa att skriva känslor
3. Verifiera att AI-svar genereras
4. Testa anslagstavlan och emoji-reaktioner

## Funktioner som är redo

✅ **AI-integration** - OpenAI GPT-3.5-turbo
✅ **Känslomässig analys** - Kontextuella svar baserat på känslor
✅ **Anslagstavla** - Dela inlägg med gemenskapen
✅ **Emoji-reaktioner** - Hjärta, kram, stöd, styrka
✅ **Responsiv design** - Fungerar på alla enheter
✅ **Lokal lagring** - Data sparas i webbläsaren
✅ **Säkerhet** - Anonym användning, ingen server-kommunikation

## Tekniska detaljer

- **AI-modell**: GPT-3.5-turbo
- **Max tokens**: 200 per svar
- **Temperature**: 0.7 (balanserad kreativitet)
- **Språk**: Svenska
- **Lagring**: localStorage (max 100 inlägg)

## Felsökning

### AI svarar inte
1. Kontrollera att `config.js` är korrekt uppladdad
2. Verifiera API-nyckeln i WordPress
3. Testa med `test.html` lokalt

### CSS/JS laddas inte
1. Kontrollera att filerna är uppladdade i WordPress Media
2. Verifiera att URL:erna i HTML-koden är korrekta
3. Använd webbläsarens utvecklarverktyg för att se fel

### Prestanda
- AI-svar tar 1-3 sekunder att generera
- Lokal lagring begränsas till 100 inlägg
- Alla data lagras lokalt (ingen server-kommunikation)

## Support
För tekniska problem:
1. Kontrollera webbläsarens utvecklarverktyg (F12)
2. Verifiera att alla filer är korrekt uppladdade
3. Testa med `test.html` för att isolera problem
