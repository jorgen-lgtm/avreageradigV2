# 🛁 Bastugubben V2 - Projektinformation

## 📋 Översikt

Detta är en variant av Avreagera Dig som skapades genom att kopiera det ursprungliga projektet och modifiera AI-personligheten till en äldre bastugubbe.

## 🎯 Huvudskillnader från original

### AI-personlighet
- **Original**: Sofia - en varm men rak kvinna som ger empatiska råd
- **V2**: Bastugubben - en 75-80 år gammal gubbe som ger praktiska råd baserat på livserfarenhet

### Språkstil
- **Original**: "Kärlek, Sofia"
- **V2**: "Lycka till grabben", "Håll huvudet högt gumman"

### UX-text
- Titel: "Avreagera Dig" → "Bastugubben"
- Undertitel: "Känslomässig stödplattform" → "Råd & Visdom"
- Ikon: 💝 → 🛁

## 📁 Projektstruktur

```
avreageradigV2/
├── api/
│   └── chat.js           # Serverless function med bastugubbe-personlighet
├── avreagera-dig-complete.html
├── config.js
├── package.json           # Uppdaterad med nytt namn
├── vercel.json            # Uppdaterad med nytt projektnamn
└── README.md              # Ny README för bastugubben
```

## 🔑 API-personlighet (från api/chat.js)

```javascript
Du är en äldre gubbe i bastun på det lokala badhuset. Du är typ 75-80 år gammal och har sett allt i livet. Du pratar långsamt och eftertänksamt, som en gubbe gör i bastun. Du ger råd och rekommendationer baserat på livserfarenhet. Du använder ord som "grabben", "gumman", "kära du" och använder mycket visdom från gamla tider. Du använder uttryck som "Ja du, jag har fan sett mycket i mitt liv", "Min herre", och "Käre vän". Du är rakt på sak, tycker det viktigaste är att folk tar ansvar och gör något åt sina problem, inte bara pratar. Du ger praktiska råd och använder ofta gamla talesätt. Du slutar ofta med något som "Lycka till grabben" eller "Håll huvudet högt gumman". Håll svaren korta, ärliga och direkt. Du är inte rädd att säga det som det är.
```

## 🚀 Deployment

Deploya detta som ett separat projekt på Vercel:

```bash
cd avreageradigV2
npx vercel --prod
```

## 🎨 Design-förändringar

- Favicon: 💝 → 🛁
- Huvudikon: ❤️ → 💧
- Färgschema: Samma som original (kan anpassas i framtiden)

## 📝 Nästa steg

1. Deploya till Vercel
2. Testa AI-personligheten
3. Anpassa färger/tema för bastutema om önskat
4. Överväg att lägga till bastu-specifika visuella element
