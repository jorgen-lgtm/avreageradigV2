# 🚀 GitHub Upload Guide - Avreagera Dig

## 📁 Repository: https://github.com/jorgen-lgtm/avreageradig

### Steg 1: Ladda upp filer via GitHub Web Interface

1. **Gå till din repository**: https://github.com/jorgen-lgtm/avreageradig
2. **Klicka "Add file"** → **"Upload files"**
3. **Dra och släpp** alla filer från projektmappen
4. **Skriv commit-meddelande**: "Uppdatera med ny OpenAI API-nyckel och förbättrade funktioner"
5. **Klicka "Commit changes"**

### Steg 2: Viktiga filer att ladda upp

**Huvudfiler:**
- ✅ `avreagera-dig-complete.html` - Komplett applikation
- ✅ `demo.html` - Interaktiv demosida
- ✅ `index.html` - Startsida
- ✅ `vercel.json` - Vercel-konfiguration
- ✅ `package.json` - Projektmetadata

**Konfigurationsfiler:**
- ✅ `config.js` - AI-inställningar med OpenAI API-nyckel
- ✅ `styles.css` - Styling (backup)
- ✅ `script.js` - JavaScript (backup)

**Dokumentation:**
- ✅ `README.md` - Projektbeskrivning
- ✅ `DEPLOYMENT-INSTRUCTIONS.md` - Publiceringsguide
- ✅ `README-vercel.md` - Vercel-guide

### Steg 3: Aktivera GitHub Pages (Valfritt)

1. **Gå till Settings** i din repository
2. **Scrolla ner till "Pages"**
3. **Välj "Deploy from a branch"**
4. **Välj "main" branch**
5. **Klicka "Save"**
6. **Din sida blir live på**: `https://jorgen-lgtm.github.io/avreageradig/`

### Steg 4: Koppla till Vercel för automatisk deployment

1. **Gå till [vercel.com](https://vercel.com)**
2. **Logga in med GitHub**
3. **Klicka "New Project"**
4. **Välj din repository**: `jorgen-lgtm/avreageradig`
5. **Klicka "Deploy"**
6. **Vercel bygger automatiskt projektet**

### 🔗 URL-struktur efter deployment:

**GitHub Pages:**
- **Huvudapplikation**: `https://jorgen-lgtm.github.io/avreageradig/avreagera-dig-complete.html`
- **Demosida**: `https://jorgen-lgtm.github.io/avreageradig/demo.html`
- **Startsida**: `https://jorgen-lgtm.github.io/avreageradig/`

**Vercel (Rekommenderat):**
- **Huvudapplikation**: `https://avreageradig.vercel.app/app`
- **Demosida**: `https://avreageradig.vercel.app/demo`
- **Startsida**: `https://avreageradig.vercel.app/`

### 🎯 Funktioner som fungerar:

- ✅ **Sofia:s AI-stöd** med OpenAI API
- ✅ **Anslagstavla** med emoji-reaktioner
- ✅ **Admin-moderering** för att ta bort stötande kommentarer
- ✅ **Responsiv design** som fungerar på alla enheter
- ✅ **Lokal lagring** för anonym användning

### 🧪 Testa efter publicering:

1. **Öppna huvudapplikationen**
2. **Skriv en känsla** som "Jag känner mig ledsen"
3. **Klicka "Få stöd från Sofia"**
4. **Se Sofia:s empatiska svar**
5. **Dela på anslagstavlan**
6. **Testa emoji-reaktioner**
7. **Aktivera admin-läge** och testa moderering

### 📞 Support:

Om du stöter på problem:
1. Kontrollera att alla filer är korrekt uppladdade
2. Testa lokalt först med `python3 -m http.server 8000`
3. Kontrollera webbläsarens konsol för fel
4. Se till att JavaScript är aktiverat

**Lycka till med publiceringen! 🚀**
