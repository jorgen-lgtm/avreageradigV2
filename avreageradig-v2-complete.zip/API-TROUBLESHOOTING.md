# 🔧 OpenAI API Felsökning

## ❌ **Problem: 401 Authentication Error**

### **Vad betyder 401-felet?**
- **401 Unauthorized** = API-nyckeln är ogiltig eller saknas
- **Möjliga orsaker:**
  - API-nyckeln är felaktig
  - API-nyckeln har gått ut
  - API-nyckeln har inte rätt behörigheter
  - Miljövariabeln är inte korrekt konfigurerad

### ✅ **Lösningar:**

#### **1. Kontrollera API-nyckeln:**
```bash
# Testa API-nyckeln lokalt
curl -H "Authorization: Bearer YOUR_API_KEY" \
     -H "Content-Type: application/json" \
     https://api.openai.com/v1/models
```

#### **2. För lokal utveckling:**
```bash
# Skapa .env-fil med din API-nyckel
echo "OPENAI_API_KEY=sk-proj-your-actual-key-here" > .env

# Starta servern
python3 -m http.server 8000
```

#### **3. För Vercel deployment:**
1. **Gå till Vercel Dashboard**
2. **Välj ditt projekt**
3. **Settings → Environment Variables**
4. **Lägg till:**
   - **Name**: `OPENAI_API_KEY`
   - **Value**: `sk-proj-your-actual-key-here`
   - **Environment**: Production, Preview, Development
5. **Redeploy** projektet

#### **4. För GitHub Pages:**
- GitHub Pages stöder inte miljövariabler
- Använd Vercel eller Netlify istället
- Eller använd bara simulerade svar

### 🔄 **Automatisk fallback:**

Applikationen har nu **intelligent fallback**:
- ✅ **Försöker OpenAI API** först
- ✅ **Fallback till simulerade svar** vid fel
- ✅ **Inga felmeddelanden** för användaren
- ✅ **Sofia fungerar alltid** med kontextuella svar

### 🧪 **Testa API-nyckeln:**

**1. Kontrollera format:**
```
✅ Korrekt: sk-proj-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
❌ Fel:    sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
```

**2. Testa behörigheter:**
- Gå till OpenAI Dashboard
- Kontrollera att API-nyckeln är aktiv
- Kontrollera att du har krediter

**3. Testa lokalt:**
```bash
# Starta servern
python3 -m http.server 8000

# Öppna i webbläsare
open http://localhost:8000/avreagera-dig-complete.html

# Testa Sofia med olika känslor
```

### 🚀 **Rekommenderad lösning:**

**För produktion:**
1. **Använd Vercel** med miljövariabler
2. **Konfigurera API-nyckeln** i Vercel Dashboard
3. **Testa live-versionen**

**För utveckling:**
1. **Använd .env-fil** lokalt
2. **Testa med simulerade svar** först
3. **Konfigurera API-nyckeln** när du är redo

### 📞 **Support:**

Om problemet kvarstår:
1. **Kontrollera OpenAI Dashboard** för API-nyckel status
2. **Testa med ny API-nyckel**
3. **Kontrollera Vercel miljövariabler**
4. **Använd simulerade svar** som backup

**Sofia fungerar alltid - även utan OpenAI API! 🎯**
