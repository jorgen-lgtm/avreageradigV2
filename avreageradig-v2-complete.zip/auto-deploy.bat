@echo off
REM 🚀 Avreagera Dig - Automatisk Deployment Script (Windows)
REM Detta skript hjälper dig att deploya Sofia's stödplattform på olika plattformar

echo 💝 Avreagera Dig - Automatisk Deployment
echo ========================================
echo.

REM API-nyckel
set API_KEY=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

REM Kontrollera att zip-filen finns
if not exist "avreagera-dig-LATEST-API.zip" (
    echo ❌ Fel: avreagera-dig-LATEST-API.zip hittades inte!
    echo Kontrollera att du är i rätt mapp och att zip-filen finns.
    pause
    exit /b 1
)

echo ✅ Zip-fil hittad: avreagera-dig-LATEST-API.zip
echo.

:menu
echo Välj deployment-alternativ:
echo.
echo 1. 🌟 Vercel (Rekommenderat)
echo 2. 🌐 Netlify
echo 3. 📄 GitHub Pages
echo 4. 🧪 Lokal test
echo 5. 📦 Extrahera zip-fil
echo 6. 🔧 Visa API-nyckel
echo 7. ❌ Avsluta
echo.
set /p choice="Välj alternativ (1-7): "

if "%choice%"=="1" goto vercel
if "%choice%"=="2" goto netlify
if "%choice%"=="3" goto github
if "%choice%"=="4" goto local
if "%choice%"=="5" goto extract
if "%choice%"=="6" goto apikey
if "%choice%"=="7" goto end
echo ❌ Ogiltigt val. Välj 1-7.
goto menu

:vercel
echo 🚀 Vercel Deployment
echo ==========================
echo.
echo Steg-för-steg:
echo 1. Gå till: https://vercel.com/new
echo 2. Logga in med GitHub
echo 3. Välj repository eller ladda upp zip-fil
echo 4. Konfigurera Environment Variable:
echo    - Name: OPENAI_API_KEY
echo    - Value: %API_KEY%
echo 5. Klicka 'Deploy'
echo.
echo Resultat: https://avreageradig.vercel.app
echo.
echo Öppnar Vercel Dashboard...
start https://vercel.com/new
goto menu

:netlify
echo 🌐 Netlify Deployment
echo ========================
echo.
echo Steg-för-steg:
echo 1. Gå till: https://netlify.com
echo 2. Logga in med GitHub
echo 3. Klicka 'New site from Git'
echo 4. Välj din repository
echo 5. Konfigurera Environment Variable:
echo    - Name: OPENAI_API_KEY
echo    - Value: %API_KEY%
echo 6. Klicka 'Deploy site'
echo.
echo Resultat: https://avreageradig.netlify.app
echo.
echo Öppnar Netlify Dashboard...
start https://netlify.com
goto menu

:github
echo 📄 GitHub Pages Deployment
echo =============================
echo.
echo Steg-för-steg:
echo 1. Gå till: https://github.com/jorgen-lgtm/avreageradig
echo 2. Ladda upp filer via GitHub web interface
echo 3. Gå till Settings → Pages
echo 4. Source: Deploy from a branch
echo 5. Branch: main
echo 6. Klicka 'Save'
echo.
echo Resultat: https://jorgen-lgtm.github.io/avreageradig/
echo OBS: GitHub Pages använder simulerade svar (ingen API-nyckel)
echo.
echo Öppnar GitHub Repository...
start https://github.com/jorgen-lgtm/avreageradig
goto menu

:local
echo 🧪 Lokal Test
echo ==============
echo.
echo Startar lokal server...
echo Startar Python HTTP server på port 8000...
echo Öppna: http://localhost:8000
echo.
echo Tryck Ctrl+C för att stoppa servern
echo.
python -m http.server 8000
goto menu

:extract
echo 📦 Extrahera Zip-fil
echo =====================
echo.
set EXTRACT_DIR=avreagera-dig-extracted
if exist "%EXTRACT_DIR%" (
    echo Tar bort befintlig mapp...
    rmdir /s /q "%EXTRACT_DIR%"
)
echo Skapar mapp: %EXTRACT_DIR%
mkdir "%EXTRACT_DIR%"
echo Extraherar zip-fil...
powershell -command "Expand-Archive -Path 'avreagera-dig-LATEST-API.zip' -DestinationPath '%EXTRACT_DIR%'"
if %errorlevel%==0 (
    echo ✅ Zip-fil extraherad till: %EXTRACT_DIR%
    echo.
    echo Innehåll:
    dir "%EXTRACT_DIR%"
    echo.
    echo För att köra lokalt:
    echo cd %EXTRACT_DIR% ^&^& python -m http.server 8000
) else (
    echo ❌ Fel vid extraktion av zip-fil!
)
goto menu

:apikey
echo 🔑 API-nyckel Information
echo =========================
echo.
echo OpenAI API-nyckel:
echo %API_KEY%
echo.
echo Denna nyckel är redan konfigurerad i zip-filen.
echo För production, använd miljövariabler istället.
echo.
echo Miljövariabel för deployment:
echo Name: OPENAI_API_KEY
echo Value: %API_KEY%
goto menu

:end
echo 👋 Tack för att du använde deployment-scriptet!
pause
exit /b 0




