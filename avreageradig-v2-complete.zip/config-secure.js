// Secure configuration for Avreagera Dig
// This file should be used for production deployment

const config = {
    ai: {
        // Set to true to use OpenAI API, false for simulated responses
        useOpenAI: true,
        
        // OpenAI API Key from environment variable (SECURE)
        openaiApiKey: process.env.OPENAI_API_KEY || 'YOUR_OPENAI_API_KEY_HERE',
        
        // OpenAI Model to use
        model: 'gpt-3.5-turbo',
        
        // Maximum tokens for AI response
        maxTokens: 200,
        
        // Temperature for AI creativity (0.0 = deterministic, 1.0 = creative)
        temperature: 0.7
    },
    app: {
        // Maximum number of posts to store
        maxPosts: 50,
        
        // Maximum characters for user input
        maxInputLength: 500,
        
        // Auto-save interval (milliseconds)
        autoSaveInterval: 30000
    },
    ui: {
        // Show timestamps on posts
        showTimestamps: true,
        
        // Animation duration (milliseconds)
        animationDuration: 300,
        
        // Theme settings
        theme: 'dark'
    }
};

// Export for Node.js environments
if (typeof module !== 'undefined' && module.exports) {
    module.exports = config;
}

// Make available globally for browser
if (typeof window !== 'undefined') {
    window.config = config;
}
