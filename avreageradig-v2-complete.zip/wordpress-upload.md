# WordPress Uppladdning - Avreagera Dig

## Instruktioner för uppladdning till avreageradig.wordpress.com

### Steg 1: Förbered filer
1. Zippa alla filer i projektet:
   - `index.html`
   - `styles.css`
   - `script.js`
   - `config.js`
   - `README.md`

### Steg 2: WordPress-uppladdning
1. Logga in på din WordPress-webbplats
2. Gå till **Utseende > Teman**
3. Klicka på **Lägg till nytt** > **Ladda upp tema**
4. Välj din zip-fil och ladda upp

### Steg 3: Aktivera applikationen
1. Gå till **Utseende > Teman**
2. Aktivera "Avreagera Dig" temat
3. Gå till **Sidor > Alla sidor**
4. Skapa en ny sida med namnet "Avreagera Dig"
5. I sidredigeraren, växla till **HTML-läge**
6. Klistra in följande kod:

```html
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avreagera Dig - Känslomässig stödplattform</title>
    <link rel="stylesheet" href="styles.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body>
    <div class="container">
        <!-- Header -->
        <header class="header">
            <h1><i class="fas fa-heart"></i> Avreagera Dig</h1>
            <p>En säker plats att ventilera dina känslor och få stöd</p>
        </header>

        <!-- Main Content -->
        <main class="main-content">
            <!-- Input Section -->
            <section class="input-section">
                <div class="input-container">
                    <h2>Vad känns det som idag?</h2>
                    <textarea 
                        id="emotionInput" 
                        placeholder="Skriv här vad du känner, vad som hänt, eller vad du behöver ventilera... Detta är en säker plats att vara ärlig med dina känslor."
                        rows="4"
                    ></textarea>
                    <button id="submitBtn" class="submit-btn">
                        <i class="fas fa-paper-plane"></i> Få stöd från AI
                    </button>
                </div>
            </section>

            <!-- AI Response Section -->
            <section id="aiResponseSection" class="ai-response-section" style="display: none;">
                <div class="ai-response-container">
                    <h3><i class="fas fa-robot"></i> AI:s stöttande svar</h3>
                    <div id="aiResponse" class="ai-response"></div>
                    <button id="shareBtn" class="share-btn">
                        <i class="fas fa-share"></i> Dela på anslagstavlan
                    </button>
                </div>
            </section>

            <!-- Community Board -->
            <section class="community-board">
                <h2><i class="fas fa-users"></i> Gemenskapens anslagstavla</h2>
                <div id="postsContainer" class="posts-container">
                    <!-- Posts will be dynamically added here -->
                </div>
            </section>
        </main>

        <!-- Loading Overlay -->
        <div id="loadingOverlay" class="loading-overlay" style="display: none;">
            <div class="loading-spinner">
                <i class="fas fa-heart fa-pulse"></i>
                <p>AI:n tänker och skapar ett stöttande svar...</p>
            </div>
        </div>
    </div>

    <script src="config.js"></script>
    <script src="script.js"></script>
</body>
</html>
```

### Steg 4: Ladda upp CSS och JavaScript-filer
1. Gå till **Medier > Lägg till nytt**
2. Ladda upp `styles.css`
3. Ladda upp `script.js`
4. Ladda upp `config.js`
5. Kopiera URL:erna för varje fil

### Steg 5: Uppdatera filvägar
Uppdatera HTML-koden med de korrekta URL:erna för CSS och JavaScript-filerna från WordPress Media Library.

### Steg 6: Testa applikationen
1. Besök din sida på avreageradig.wordpress.com
2. Testa att skriva känslor och få AI-svar
3. Testa att dela på anslagstavlan
4. Testa emoji-reaktioner

### Steg 7: Konfiguration (valfritt)
För att använda riktig AI:
1. Redigera `config.js` med din OpenAI API-nyckel
2. Ladda upp den uppdaterade filen
3. Uppdatera HTML-koden med den nya URL:en

### Felsökning
- **CSS laddas inte**: Kontrollera att CSS-filen är korrekt uppladdad och URL:en är rätt
- **JavaScript fungerar inte**: Kontrollera att alla JS-filer är uppladdade och URL:erna är korrekta
- **AI svarar inte**: Kontrollera att `config.js` är korrekt konfigurerad

### Säkerhet
- All data lagras lokalt i användarens webbläsare
- Ingen server-kommunikation (förutom valfri AI API)
- Anonym användning - inga personuppgifter samlas in

### Support
För tekniska problem, kontrollera:
1. Att alla filer är korrekt uppladdade
2. Att URL:erna i HTML-koden matchar WordPress Media Library
3. Att webbläsarens utvecklarverktyg inte visar fel
