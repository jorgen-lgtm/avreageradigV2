# 🚀 Vercel Deployment Guide - Avreagera Dig V2

## 🎯 **Din Vercel App:**
**URL**: https://avreageradig-v2-bgzu.vercel.app/

---

## 🚀 **Snabb Deployment:**

### **1. Vercel Dashboard (Rekommenderat) 🌟**

1. **Gå till**: https://vercel.com/dashboard
2. **Hitta ditt projekt**: `avreageradig-v2`
3. **Klicka på projektet**
4. **Gå till**: Settings → Environment Variables
5. **Lägg till ny variabel:**
   - **Name**: `OPENAI_API_KEY`
   - **Value**: `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`
   - **Environment**: Production, Preview, Development (markera alla)
6. **Klicka "Save"**
7. **Gå till Deployments** och klicka **"Redeploy"**

### **2. GitHub Push (Automatisk) 📄**

```bash
git add .
git commit -m "Update Sven AI"
git push origin main
```

Vercel deployar automatiskt när du pushar!

---

## 🎯 **URLs efter deployment:**

### **Huvudsida:**
- **URL**: https://avreageradig-v2-bgzu.vercel.app/
- **Beskrivning**: Sofia's mental health support app

### **Sven (Bastugubben):**
- **URL**: https://avreageradig-v2-bgzu.vercel.app/sven
- **Beskrivning**: 78-årig bastugubbe med riktig AI

### **Demo:**
- **URL**: https://avreageradig-v2-bgzu.vercel.app/demo
- **Beskrivning**: Demo-version

---

## 🧖‍♂️ **Testa Sven med riktig AI:**

### **Frågor att testa:**
1. "Jag känner mig ledsen och ensam"
2. "Jag har problem på jobbet"
3. "Jag vet inte vad jag ska göra med mitt liv"
4. "Jag är rädd för framtiden"
5. "Jag har problem i min relation"

### **Förväntade svar:**
- **Riktiga AI-svar** från OpenAI GPT-3.5-turbo
- **Sven's personlighet** - rakt på sak, ärlig
- **Autentiska uttryck** - "grabben", "gumman", "ja du"
- **Praktiska råd** baserat på 40 års bastu-erfarenhet

---

## 🔧 **Teknisk konfiguration:**

### **Environment Variables:**
- **Name**: `OPENAI_API_KEY`
- **Value**: `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`
- **Environment**: Production, Preview, Development

### **API Endpoints:**
- **Sven AI**: `/api/sven`
- **Sofia AI**: `/api/chat`

### **Routing:**
- **Huvudsida**: `/` → `avreagera-dig-complete.html`
- **Sven**: `/sven` → `bastugubben-sven.html`
- **Demo**: `/demo` → `demo.html`

---

## 🎉 **Efter deployment:**

### **Sven kommer att:**
✅ **Använda riktig AI** från OpenAI  
✅ **Ge personliga svar** baserat på dina frågor  
✅ **Behålla sin personlighet** som bastugubbe  
✅ **Ge praktiska råd** från 40 års erfarenhet  
✅ **Använda autentiska uttryck** och visdom  

### **Sofia kommer att:**
✅ **Använda riktig AI** från OpenAI  
✅ **Ge empatiska svar** för mental hälsa  
✅ **Behålla sin personlighet** som stödjande AI  
✅ **Ge praktiska råd** för känslomässig välbefinnande  

---

## 🚀 **Deploy nu:**

**Kör deployment-scriptet:**
```bash
./deploy-to-vercel.sh
```

**Eller gå direkt till Vercel Dashboard:**
https://vercel.com/dashboard

**Sven och Sofia väntar på att hjälpa folk med riktig AI! 🧖‍♂️🤖**
