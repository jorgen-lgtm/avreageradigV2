# 🚀 WordPress Uppladdning - Steg för Steg

## Steg 1: Logga in på WordPress
1. Gå till: **avreageradig.wordpress.com/wp-admin**
2. Logga in med:
   - **Användare**: avreageradig@gmail.com
   - **Lösenord**: Fanintenuocksa213

## Steg 2: Skapa ny sida
1. I WordPress-dashboard, klicka **"Sidor"** i menyn till vänster
2. Klicka **"Lägg till ny"** (blå knapp)
3. Skriv titel: **"Avreagera Dig"**

## Steg 3: Kopiera HTML-koden
1. **Öppna filen** `avreagera-dig-complete.html` i din textredigerare
2. **Markera ALLT** (Ctrl+A eller Cmd+A)
3. **Kopiera** (Ctrl+C eller Cmd+C)

## Steg 4: Klistra in i WordPress
1. I WordPress-redigeraren, klicka på **tre prickar** (⋮) längst upp till höger
2. Klicka **"Redigera som HTML"**
3. **Klistra in** allt innehåll (Ctrl+V eller Cmd+V)
4. **Spara** (Ctrl+S)

## Steg 5: Publicera
1. Klicka **"Publicera"** (blå knapp)
2. **Klar!** Din sida är live på: avreageradig.wordpress.com/avreagera-dig

## ⚠️ Viktiga tips:
- **Använd HTML-läge** - inte visuell redigerare
- **Kopiera ALLT** från HTML-filen
- **Spara ofta** medan du arbetar
- **Testa sidan** efter publicering

## 🆘 Om det inte fungerar:
- Kontrollera att du är i HTML-läge
- Se till att allt innehåll kopierades
- Prova att spara och uppdatera sidan
