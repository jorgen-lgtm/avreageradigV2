# 🧖‍♂️ Sven AI Deployment - Vercel

## 🎯 **Mål: Få Sven att använda riktig OpenAI AI**

### ✅ **Filer redo:**
- `bastugubben-sven.html` - Sven's GUI
- `api/sven.js` - Sven's AI serverless function  
- `vercel.json` - Routing konfiguration
- `package.json` - Dependencies

---

## 🚀 **DEPLOYMENT STEG:**

### **1. Gå till Vercel**
**URL:** https://vercel.com/new

### **2. Import Repository**
- **Repository:** `jorgen-lgtm/avreageradig`
- **Klicka:** "Import"

### **3. Konfigurera Environment Variables**
- **Gå till:** Settings → Environment Variables
- **Lägg till:**
  - **Name:** `OPENAI_API_KEY`
  - **Value:** `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`
  - **Environment:** Production, Preview, Development (markera alla)
- **Klicka:** "Save"

### **4. Deploy**
- **Klicka:** "Deploy"
- **Vänta:** 2-3 minuter för deployment

---

## 🎯 **URLs efter deployment:**

### **Sven med riktig AI:**
- **Sven:** `https://avreageradig.vercel.app/sven`
- **Huvudsida:** `https://avreageradig.vercel.app`
- **Demo:** `https://avreageradig.vercel.app/demo`

---

## 🧪 **Testa Sven med riktig AI:**

### **Frågor att testa:**
1. "Jag känner mig ledsen och ensam"
2. "Jag har problem på jobbet"
3. "Jag vet inte vad jag ska göra med mitt liv"
4. "Jag är rädd för framtiden"
5. "Jag har problem i min relation"

### **Förväntade svar:**
- **Riktiga AI-svar** från OpenAI GPT-3.5-turbo
- **Sven's personlighet** - rakt på sak, ärlig
- **Autentiska uttryck** - "grabben", "gumman", "ja du"
- **Praktiska råd** baserat på 40 års bastu-erfarenhet

---

## 🔧 **Teknisk konfiguration:**

### **API Endpoint:**
- **URL:** `/api/sven`
- **Method:** POST
- **Body:** `{"message": "din fråga"}`

### **Sven's AI Personlighet:**
```
Du är Sven, en 78-årig bastugubbe som har suttit i bastun i 40 år. 
Du är rakt på sak, ärlig och ger praktiska råd baserat på livserfarenhet. 
Du använder uttryck som "grabben", "gumman", "ja du", "min herre", "käre vän". 
Du är inte rädd att säga det som det är och tycker det viktigaste är att folk tar ansvar för sina handlingar.
```

### **AI Inställningar:**
- **Model:** gpt-3.5-turbo
- **Max tokens:** 300
- **Temperature:** 0.7
- **Personlighet:** Bastugubbe Sven, 78 år

---

## 🎉 **Efter deployment:**

### **Sven kommer att:**
✅ **Använda riktig AI** från OpenAI  
✅ **Ge personliga svar** baserat på dina frågor  
✅ **Behålla sin personlighet** som bastugubbe  
✅ **Ge praktiska råd** från 40 års erfarenhet  
✅ **Använda autentiska uttryck** och visdom  

### **Testa gärna:**
- **Känslor:** "Jag känner mig ledsen"
- **Problem:** "Jag har problem på jobbet"  
- **Framtiden:** "Jag vet inte vad jag ska göra"
- **Relationer:** "Jag har problem i min relation"

---

## 🚀 **DEPLOY NU:**

**Gå till:** https://vercel.com/new  
**Import:** `jorgen-lgtm/avreageradig`  
**Lägg till API-nyckel** som environment variable  
**Deploy** → Sven får riktig AI!  

**Sven väntar på att hjälpa folk med riktig AI i bastun! 🧖‍♂️🔥**
